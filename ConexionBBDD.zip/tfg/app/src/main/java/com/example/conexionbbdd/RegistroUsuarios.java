package com.example.conexionbbdd;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.sql.Connection;
import java.sql.PreparedStatement;



public class RegistroUsuarios extends AppCompatActivity {

    EditText nombreapellidos, email, telefono, usuario, clave, repetirClave;
    Button registrar;
    TextView ingresar;
    Connection con;

    public RegistroUsuarios() {
        Conexion instanceConnection = new Conexion();
        con = instanceConnection.connect();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registro_usuarios);

        nombreapellidos = findViewById(R.id.txtnomapellidos);
        email = findViewById(R.id.txtemail);
        telefono = findViewById(R.id.txttelefono);
        usuario = findViewById(R.id.txtusuario);
        clave = findViewById(R.id.txtclave);
        repetirClave = findViewById(R.id.txtrepetirclave);
        registrar = findViewById(R.id.btnregistrar);
        ingresar = findViewById(R.id.lbliniciarsesion);

        registrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                registrar(view);
            }
        });

        ingresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent ingresar = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(ingresar);
                finish();
            }
        });
    }

    public void registrar(View view) {
        try {
            String email = this.email.getText().toString();
            String contraseña = clave.getText().toString();
            String repetirContraseña = repetirClave.getText().toString();

            if (!contraseña.equals(repetirContraseña)) {
                Toast.makeText(this, "Las contraseñas no coinciden", Toast.LENGTH_SHORT).show();
                return;
            }
            if (!email.contains("@")) {
                Toast.makeText(this, "El email debe contener '@'", Toast.LENGTH_SHORT).show();
                return;
            }

            if (con == null) {
                Toast.makeText(this, "Error de conexión", Toast.LENGTH_SHORT).show();
                return;
            }

            // Validar correo
            PreparedStatement comprobarCorreo = con.prepareStatement("SELECT * FROM usuarios WHERE correo = ?");
            comprobarCorreo.setString(1, email);
            java.sql.ResultSet resultadoCorreo = comprobarCorreo.executeQuery();
            if (resultadoCorreo.next()) {
                Toast.makeText(this, "Este correo electrónico ya está registrado", Toast.LENGTH_SHORT).show();
                return;
            }


            // Validar teléfono
            PreparedStatement comprobarTelefono = con.prepareStatement("SELECT * FROM usuarios WHERE telefono = ?");
            comprobarTelefono.setString(1, telefono.getText().toString());
            java.sql.ResultSet resultadoTelefono = comprobarTelefono.executeQuery();
            if (resultadoTelefono.next()) {
                Toast.makeText(this, "Este número de teléfono ya está registrado", Toast.LENGTH_SHORT).show();
                return;
            }

            // Validar nombre de usuario
            PreparedStatement comprobarUsuario = con.prepareStatement("SELECT * FROM usuarios WHERE usuario = ?");
            comprobarUsuario.setString(1, usuario.getText().toString());
            java.sql.ResultSet resultadoUsuario = comprobarUsuario.executeQuery();
            if (resultadoUsuario.next()) {
                Toast.makeText(this, "Este nombre de usuario ya está en uso", Toast.LENGTH_SHORT).show();
                return;
            }

            // Insertar nuevo usuario
            PreparedStatement insertar = con.prepareStatement("INSERT INTO usuarios (nombrecompleto, correo, telefono, usuario, contrasena) VALUES(?,?,?,?,?)");
            insertar.setString(1, nombreapellidos.getText().toString());
            insertar.setString(2, email);
            insertar.setString(3, telefono.getText().toString());
            insertar.setString(4, usuario.getText().toString());
            insertar.setString(5, clave.getText().toString());

            insertar.executeUpdate();

            Toast.makeText(this, "Cliente agregado correctamente", Toast.LENGTH_SHORT).show();

            nombreapellidos.setText("");
            this.email.setText("");
            telefono.setText("");
            usuario.setText("");
            clave.setText("");
            repetirClave.setText("");

        } catch (Exception e) {
            Log.e("Error de conexión", e.getMessage());
        }
    }

}