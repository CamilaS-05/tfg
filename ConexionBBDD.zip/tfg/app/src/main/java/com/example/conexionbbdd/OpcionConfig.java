package com.example.conexionbbdd;

public class OpcionConfig {
    public String titulo;
    public int icono;

    public OpcionConfig(String titulo, int icono) {
        this.titulo = titulo;
        this.icono = icono;
    }
}
