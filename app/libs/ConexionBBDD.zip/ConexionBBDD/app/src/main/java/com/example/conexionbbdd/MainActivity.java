package com.example.conexionbbdd;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etNombre, etApellido;
    private Button btnInsertar;
    private  Conexion c;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Vincular elementos del XML
        etNombre = findViewById(R.id.etNombre);
        etApellido = findViewById(R.id.etApellido);
        btnInsertar = findViewById(R.id.btnInsertar);
        c = new Conexion();

        // Evento del botón para insertar cliente
        btnInsertar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nombre = etNombre.getText().toString().trim();
                String apellido = etApellido.getText().toString().trim();


                if (!nombre.isEmpty() && !apellido.isEmpty() ) {
                    if (c.insertarPersona(nombre, apellido )) {
                        Toast.makeText(MainActivity.this, "Cliente insertado correctamente", Toast.LENGTH_SHORT).show();
                        etNombre.setText("");
                        etApellido.setText("");

                    } else {
                        Toast.makeText(MainActivity.this, "Error al insertar", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(MainActivity.this, "Rellena todos los campos", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}